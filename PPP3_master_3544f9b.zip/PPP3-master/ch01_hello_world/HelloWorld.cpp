//This program outputs the message "Hello, World!" to the monitor. -

#include "PPP.h"		// Provides access to the Standard Library using namespace std also provides range checking and other utilities. -

int main()		// C++ programs start by executing the function main -
{
	std::cout << "Hello, World!\n";		// output "Hello, World!" -
	return 0;
}